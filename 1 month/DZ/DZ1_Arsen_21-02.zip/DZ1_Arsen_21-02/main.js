//Задание 1

/*var name=prompt("Укажите своё имя:");
var surname=prompt("Укажите свою фамилию:");
alert("Здравствуйте "+name+" "+surname);*/


//Задание 2

/*a = Number(prompt('Введите первое число'));
b = Number(prompt('Введите второе число'));

max = function ()
{
    if (isNaN(a) || isNaN(b)) console.log("Вы должны ввести числа!");
    else{
        if (a > b){
            console.log(a)
        } else if (a === b){
            console.log('Числа равны')
        } else {
            console.log(b);
        }
    }
}    

max();*/


// Задание 3

/*a = prompt('Введите цвет');

b = "красный"
с = "желтый"
d = "зеленый"

color = function (){
    if  (a === b){
        console.log("Стой")
    } else if (a === с){
        console.log("Жди")
    } else if (a === d){
        console.log("Иди")   
    } else  {
        console.error("Неверный цвет светофора");
    }
}

color();*/